#include <Servo.h>
#include "mag.h"
#define dTimeDEF 5

int pinServo[7] = { 2, 3, 4, 5, 6, 7, 45 };
Servo fakeServos[12];

Servo handLeft;
Servo handRight;
Servo shoulLeft;
Servo shoulRight;
Servo earRight;
Servo earLeft;
Servo turn;

//shoulright 110 40
int shL = 90, shR = 90, hR = 50, hL = 120, eR = 110, eL = 80, tS = 90;
void handRightWrite(int pos, uint32_t dTime = dTimeDEF) {
  if (pos > hR) {
    for (int i = hR; i < pos; i++) {
      handRight.write(pos);
      delay(dTime);
    }
  } else {
    for (int i = hR; i > pos; i--) {
      handRight.write(pos);
      delay(dTime);
    }
  }
  hR = pos;
}

void handLeftWrite(int pos, uint32_t dTime = dTimeDEF) {
  if (pos > hL) {
    for (int i = hL; i < pos; i++) {
      handLeft.write(pos);
      delay(dTime);
    }
  } else {
    for (int i = hL; i > pos; i--) {
      handLeft.write(pos);
      delay(dTime);
    }
  }
  hL = pos;
}

void shoulRightWrite(int pos, uint32_t dTime = dTimeDEF) {
  if (pos > shR) {
    for (int i = shR; i < pos; i++) {
      shoulRight.write(pos);
      delay(dTime);
    }
  } else {
    for (int i = shR; i > pos; i--) {
      shoulRight.write(pos);
      delay(dTime);
    }
  }
  shR = pos;
}

void shoulLeftWrite(int pos, uint32_t dTime = dTimeDEF) {
  if (pos > shL) {
    for (int i = shL; i < pos; i++) {
      shoulLeft.write(pos);
      delay(dTime);
    }
  } else {
    for (int i = shL; i > pos; i--) {
      shoulLeft.write(pos);
      delay(dTime);
    }
  }
  shL = pos;
}

void earRightWrite(int pos, uint32_t dTime = dTimeDEF) {
  if (pos > eR) {
    for (int i = eR; i < pos; i++) {
      earRight.write(pos);
      delay(dTime);
    }
  } else {
    for (int i = eR; i > pos; i--) {
      earRight.write(pos);
      delay(dTime);
    }
  }
  eR = pos;
}

void earLeftWrite(int pos, uint32_t dTime = dTimeDEF) {
  if (pos > eL) {
    for (int i = eL; i < pos; i++) {
      earLeft.write(pos);
      delay(dTime);
    }
  } else {
    for (int i = eL; i > pos; i--) {
      earLeft.write(pos);
      delay(dTime);
    }
  }
  eL = pos;
}


void beginServo(bool fEmotion = true) {
  if (fEmotion) {
    shoulLeftWrite(90, 15);
    delay(20);
    shoulRightWrite(90, 15);
    delay(20);
    handRightWrite(70, 8);
    delay(20);
    handLeftWrite(90, 8);
    delay(20);
    earRightWrite(120, 15);
    delay(20);
    earLeftWrite(100, 15);
    delay(20);
  }
}

void _initServo() {
  /* int fakes[] = {62, 63, 64, 65, 66, 67, 68, 69, 30, 31, 32, 33};
  for(int i = 0; i < 7; i++) {
    fakeServos[i].attach(fakes[i]);
  }*/

  handLeft.attach(2, 500, 2080);
  delay(20);
  shoulLeft.attach(4);
  delay(20);
  handRight.attach(5, 700, 2540);
  delay(20);
  shoulRight.attach(3);
  delay(20);
  earLeft.attach(6);
  delay(20);
  earRight.attach(7);
  delay(20);

  beginServo();
}

void _deinitServo() {
  handLeft.detach();
  shoulLeft.detach();
  handRight.detach();
  shoulRight.detach();
  earLeft.detach();
  earRight.detach();
}

void hi() {
  shoulRightWrite(110);
  for (int j = 0; j < 2; j++) {
    for (int i = 70; i < 120; i++) {
      handRightWrite(i);
      delay(12);
    }
    for (int i = 120; i > 70; i--) {
      handRightWrite(i);
      delay(12);
    }
  }
  for (int i = 80; i > 60; i--) {
    handRightWrite(i);
    delay(12);
  }
  shoulRightWrite(90);
}

void circle() {
  shoulRightWrite(110);
  shoulLeftWrite(70);
  for (int j = 0; j < 11; j++) {
    for (int i = 80; i < 120; i++) {
      handRightWrite(i);
      handLeftWrite(map(120 - i + 80, 80, 120, 85, 45));
      delay(6);
    }
    for (int i = 120; i > 80; i--) {
      handRightWrite(i);
      handLeftWrite(map(120 - i + 80, 120, 80, 45, 85));
      delay(6);
    }
    delay(100);
  }
  for (int i = 80; i > 50; i--) {
    handRightWrite(i);
    delay(12);
  }
  shoulRightWrite(90);
  shoulLeftWrite(90);

  handRightWrite(70, 8);
  handLeftWrite(95, 8);
}

void earsOpen() {
  earRightWrite(120, 5);
  earLeftWrite(100, 5);
}

void earsClose() {
  earRightWrite(240, 5);
  earLeftWrite(20, 5);
}

void earsFly(int n = 2, uint32_t t = 200) {
  for (int i = 0; i < n; i++) {
    for (int i = 120; i < 160; i++) {
      earRightWrite(i, 5);
      earLeftWrite(map(i, 120, 160, 100, 60));
    }
    delay(200);
    //movement_of_foots(200);
    for (int i = 160; i > 120; i--) {
      earRightWrite(i, 5);
      earLeftWrite(map(i, 160, 120, 60, 100));
    }
    delay(t);
    //movement_of_foots(200);
  }
}

void handOrange() {
  shoulLeftWrite(90, 15);
  shoulRightWrite(90, 15);
  for (int i = 70; i < 120; i++) {
    handRightWrite(i - 7);
    handLeftWrite(map(i, 70, 125, 95, 35));
    delay(20);
  }

  for (int i = 90; i > 78; i--) {
    shoulRightWrite(i);
    shoulLeftWrite(map(i, 90, 78, 90, 102));
    delay(20);
  }  //*/
}

void NhandOrange() {
  for (int i = 80; i < 90; i++) {
    shoulRightWrite(i);
    shoulLeftWrite(map(i, 80, 90, 100, 90));
    delay(20);
  }

  for (int i = 60; i > 70; i--) {
    handRightWrite(i);
    handLeftWrite(map(i, 60, 70, 110, 95));
    delay(20);
  }
  //*/

  /* onMag(8000);
    offMag();*/
}

static uint32_t timerTurn = millis();
void turnServo() {
  for (int i = 90; i < 150; i++) {
    turn.write(i);
    delay(30);
  }
  for (int i = 150; i > 90; i--) {
    turn.write(i);
    delay(30);
  }
  for (int i = 90; i > 30; i--) {
    turn.write(i);
    delay(30);
  }
  for (int i = 30; i < 90; i++) {
    turn.write(i);
    delay(30);
  }
  timerTurn = millis();
}

void handClap(int dTime = 1) {
  for (int i = 70; i < 120; i++) {
    handRightWrite(i);
    handLeftWrite(map(i, 70, 120, 95, 30));
    delay(12);
  }
  stopm(200);
  for (int i = 0; i < 8; i++) {
    for (int i = 90; i > 65; i--) {
      shoulRightWrite(i);
      shoulLeftWrite(map(i, 90, 65, 90, 115));
      delay(dTime);
    }
    for (int i = 65; i < 90; i++) {
      shoulRightWrite(i);
      shoulLeftWrite(map(i, 65, 90, 115, 90));
      delay(dTime);
    }
    stopm(30);
  }
  for (int i = 120; i > 70; i--) {
    handRightWrite(i);
    handLeftWrite(map(i, 130, 70, 30, 95));
    delay(20);
  }
}


void talk() {
  shoulRightWrite(110);
  shoulLeftWrite(70);
  for (int j = 0; j < 5; j++) {
    for (int i = 60; i < 120; i++) {
      handRightWrite(i);
      handLeftWrite(map(i, 60, 120, 105, 45));
      delay(12);
    }
    for (int i = 120; i > 60; i--) {
      handRightWrite(i);
      handLeftWrite(map(i, 120, 60, 45, 105));
      delay(12);
    }
    delay(1500);
  }
  for (int i = 80; i > 50; i--) {
    handRightWrite(i);
    delay(12);
  }
  shoulRightWrite(90);
  shoulLeftWrite(90);
}

void upTabl() {
  shoulRightWrite(110);
  shoulLeftWrite(70);
  delay(3000);
  for (int j = 0; j < 1; j++) {
    for (int i = 60; i < 110; i++) {
      handRightWrite(i - 5);
      handLeftWrite(map(i, 60, 110, 105, 55));
      delay(12);
    }
  }
  delay(8000);
}

void handScream() {
  handRightWrite(50);
  handLeftWrite(120);
  for (int i = 50; i < 160; i++) {
    handRightWrite(i);
    handLeftWrite(map(i, 50, 160, 120, 10));
    delay(10);
  }
  shoulRightWrite(60);
  shoulLeftWrite(110);
}

void _testServo() {
  for (int _ = 0; _ < 2; _++) {
    for (int i = 60; i < 140; i++) {
      handRight.write(i);
      delay(60);
    }
    for (int i = 90; i < 140; i++) {
      shoulRight.write(i);
      delay(60);
    }
  }
}

void _testServoOne() {
  for (int _ = 0; _ < 2; _++) {
    for (int i = 40; i < 110; i++) {
      shoulRight.write(i);
      delay(60);
    }
    for (int i = 110; i > 40; i--) {
      shoulRight.write(i);
      delay(60);
    }
  }
}

void handOne() {
  if (Serial3.available()) {
    delay(100);
    int countSerial = Serial3.read();
    while (countSerial == 2) {
      countSerial = Serial3.read();
      for (int i = 90; i < 150; i++) {
        handLeft.write(i);
        earRight.write(i);
        delay(25);
      }
      for (int i = 150; i > 90; i--) {
        earRight.write(i);
        handLeft.write(i);
        delay(25);
      }
    }
    while (countSerial == 1) {
      countSerial = Serial3.read();
      delay(100);
      for (int i = 90; i < 150; i++) {
        handLeft.write(i + 20);
        handRight.write(270 - i);
        delay(25);
      }
      for (int i = 150; i > 90; i--) {
        handLeft.write(i + 20);
        handRight.write(270 - i);
        delay(25);
      }
    }
    while (countSerial == 0) {
      countSerial = Serial3.read();
      Serial.println(countSerial);
      continue;
    }
  }
}
